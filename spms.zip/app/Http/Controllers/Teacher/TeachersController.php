<?php

namespace App\Http\Controllers\Teacher;

use App\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class TeachersController extends Controller
{

}
