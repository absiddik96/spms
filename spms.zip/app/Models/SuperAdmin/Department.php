<?php

namespace App\Models\SuperAdmin;

use Illuminate\Database\Eloquent\Model;

class Department extends Model
{
    protected $fillable = ['dept'];
}
